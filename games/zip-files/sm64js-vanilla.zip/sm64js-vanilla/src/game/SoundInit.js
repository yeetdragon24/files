export const raise_background_noise = (a) => {}
export const play_infinite_stairs_music = () => {}
export const stop_shell_music = () => {}
export const stop_cap_music = () => {}
export const fadeout_cap_music = () => {}
export const fadeout_music = (fadeOutTime) => {}
