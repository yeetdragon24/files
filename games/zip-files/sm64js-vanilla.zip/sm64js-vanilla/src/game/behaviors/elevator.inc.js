import { MODEL_MIST } from "../../include/model_ids";

export const D_8032F3CC = {
    behParam: 3, count: 20, model: MODEL_MIST, offsetY: 20,
    forwardVelBase: 10, forwardVelRange: 5, velYBase: 0, velYRange: 0,
    gravity: 0, dragStrength: 30, sizeBase: 30.0, sizeRange: 1.5
}