export const ANIMINDEX_NUMPARTS = (animindex) => {return (animindex.length / 6) - 1}
