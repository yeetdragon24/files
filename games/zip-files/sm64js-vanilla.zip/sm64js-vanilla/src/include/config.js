export const SCREEN_WIDTH = 320
export const SCREEN_HEIGHT = 240