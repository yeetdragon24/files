// Bbh

// 0x07000000 - 0x07001000
export const bbh_seg7_texture_07000000 = []

// 0x07001000 - 0x07001800
export const bbh_seg7_texture_07001000 = []

// 0x07001800 - 0x07002000
export const bbh_seg7_texture_07001800 = []

// 0x07002000 - 0x07003000
export const bbh_seg7_texture_07002000 = []

// 0x07003000 - 0x07003400
export const bbh_seg7_texture_07003000 = []

// 0x07003400 - 0x07004400
export const bbh_seg7_texture_07003400 = []

// 0x07004400 - 0x07004800
export const bbh_seg7_texture_07004400 = []

// 2021-05-29 18:23:02 -0400 (Convert.rb 2021-05-29 17:49:14 -0400)
