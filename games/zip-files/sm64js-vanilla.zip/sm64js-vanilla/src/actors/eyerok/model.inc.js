// ** actors/eyerok/model
import * as Gbi from "../../include/gbi"

export const eyerok_seg5_texture_05008D40 = []
export const eyerok_seg5_texture_05009540 = []
export const eyerok_seg5_texture_05009D40 = []
export const eyerok_seg5_texture_0500A540 = []
export const eyerok_seg5_texture_0500AD40 = []
