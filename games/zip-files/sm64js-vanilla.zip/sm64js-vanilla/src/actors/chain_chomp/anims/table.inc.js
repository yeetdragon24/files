import { chain_chomp_seg6_anim_06025160 } from "./anim_06025160.inc"

export const chain_chomp_seg6_anims_06025178 = [
    chain_chomp_seg6_anim_06025160, null
]