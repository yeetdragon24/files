// ** actors/bubba/model
import * as Gbi from "../../include/gbi"

export const bubba_seg5_texture_05000008 = []
export const bubba_seg5_texture_05000408 = []
export const bubba_seg5_texture_05001408 = []
export const bubba_seg5_texture_05001C08 = []
export const bubba_seg5_texture_05002408 = []
