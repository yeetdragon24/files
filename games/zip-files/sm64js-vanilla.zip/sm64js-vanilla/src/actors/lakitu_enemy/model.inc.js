// ** actors/lakitu_enemy/model
import * as Gbi from "../../include/gbi"

export const lakitu_enemy_seg5_texture_0500ECE0 = []
export const lakitu_enemy_seg5_texture_0500F4E0 = []
export const lakitu_enemy_seg5_texture_050104E0 = []
export const lakitu_enemy_seg5_texture_050114E0 = []
export const lakitu_enemy_seg5_texture_05011CE0 = []
