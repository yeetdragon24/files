// ** actors/swoop/model
import * as Gbi from "../../include/gbi"

export const swoop_seg6_texture_06004270 = []
export const swoop_seg6_texture_06004A70 = []
export const swoop_seg6_texture_06005270 = []
export const swoop_seg6_texture_06005A70 = []
