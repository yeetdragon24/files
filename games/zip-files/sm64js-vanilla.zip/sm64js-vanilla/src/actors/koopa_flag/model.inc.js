// ** actors/koopa_flag/model
import * as Gbi from "../../include/gbi"

export const koopa_flag_seg6_texture_06000048 = []
