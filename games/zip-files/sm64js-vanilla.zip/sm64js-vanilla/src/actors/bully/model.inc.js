// ** actors/bully/model
import * as Gbi from "../../include/gbi"

export const bully_seg5_texture_050000E0 = []
export const bully_seg5_texture_05000468 = []
export const bully_seg5_texture_05001468 = []
export const bully_seg5_texture_05002468 = []
