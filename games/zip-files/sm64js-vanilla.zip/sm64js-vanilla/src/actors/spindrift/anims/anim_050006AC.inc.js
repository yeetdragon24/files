// ** actors/spindrift/anims/anim_050006AC
import * as Gbi from "../../../include/gbi"

export const spindrift_seg5_texture_050006D0 = []
export const spindrift_seg5_texture_05000ED0 = []
export const spindrift_seg5_texture_050016D0 = []
export const spindrift_seg5_texture_05001ED0 = []
