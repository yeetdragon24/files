// ** actors/yoshi_egg/model
import * as Gbi from "../../include/gbi"

export const yoshi_egg_seg5_texture_050057B8 = []
export const yoshi_egg_seg5_texture_05005FB8 = []
export const yoshi_egg_seg5_texture_050067B8 = []
export const yoshi_egg_seg5_texture_05006FB8 = []
export const yoshi_egg_seg5_texture_050077B8 = []
export const yoshi_egg_seg5_texture_05007FB8 = []
export const yoshi_egg_seg5_texture_050087B8 = []
export const yoshi_egg_seg5_texture_05008FB8 = []
