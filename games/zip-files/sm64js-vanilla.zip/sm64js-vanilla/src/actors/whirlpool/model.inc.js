// ** actors/whirlpool/model
import * as Gbi from "../../include/gbi"

export const whirlpool_seg5_texture_05012848 = []
