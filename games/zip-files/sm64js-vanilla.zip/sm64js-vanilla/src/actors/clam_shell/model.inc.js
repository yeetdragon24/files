// ** actors/clam_shell/model
import * as Gbi from "../../include/gbi"

export const clam_shell_seg5_texture_05000030 = []
export const clam_shell_seg5_texture_05000830 = []
