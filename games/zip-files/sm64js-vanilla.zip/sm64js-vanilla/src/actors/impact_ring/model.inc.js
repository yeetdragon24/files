// ** actors/impact_ring/model
import * as Gbi from "../../include/gbi"

export const impact_ring_seg6_texture_0601CA50 = []
export const impact_ring_seg6_texture_0601DA50 = []
