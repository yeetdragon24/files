// ** actors/monty_mole/model
import * as Gbi from "../../include/gbi"

export const monty_mole_seg5_texture_05000970 = []
export const monty_mole_seg5_texture_05001170 = []
export const monty_mole_seg5_texture_05001970 = []
export const monty_mole_seg5_texture_05002170 = []
export const monty_mole_seg5_texture_05002970 = []
