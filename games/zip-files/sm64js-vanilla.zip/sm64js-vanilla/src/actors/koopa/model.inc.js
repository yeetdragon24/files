// ** actors/koopa/model
import * as Gbi from "../../include/gbi"

export const koopa_seg6_texture_06002648 = []
export const koopa_seg6_texture_06002E48 = []
export const koopa_seg6_texture_06003648 = []
export const koopa_seg6_texture_06003E48 = []
export const koopa_seg6_texture_06004648 = []
export const koopa_seg6_texture_06004E48 = []
export const koopa_seg6_texture_06005648 = []
export const koopa_seg6_texture_06005E48 = []
