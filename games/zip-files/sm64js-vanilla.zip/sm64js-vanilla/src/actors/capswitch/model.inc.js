// ** actors/capswitch/model
import * as Gbi from "../../include/gbi"

export const capswitch_seg5_texture_05001C48 = []
export const capswitch_seg5_texture_05002C48 = []
