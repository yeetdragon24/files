// ** actors/unagi/model
import * as Gbi from "../../include/gbi"

export const unagi_seg5_texture_0500AF20 = []
export const unagi_seg5_texture_0500B720 = []
export const unagi_seg5_texture_0500B920 = []
export const unagi_seg5_texture_0500C120 = []
export const unagi_seg5_texture_0500C320 = []
export const unagi_seg5_texture_0500C3A0 = []
