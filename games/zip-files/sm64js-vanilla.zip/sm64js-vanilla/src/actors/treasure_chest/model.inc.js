// ** actors/treasure_chest/model
import * as Gbi from "../../include/gbi"

export const treasure_chest_seg6_texture_06013FA8 = []
export const treasure_chest_seg6_texture_060147A8 = []
export const treasure_chest_seg6_texture_06014FA8 = []
export const treasure_chest_seg6_texture_060157A8 = []
