import { goomba_seg8_anim_0801DA34 } from "./anim_0801DA34.inc"

export const goomba_seg8_anims_0801DA4C = [
    goomba_seg8_anim_0801DA34, null, null
]