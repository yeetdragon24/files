// ** actors/cyan_fish/model
import * as Gbi from "../../include/gbi"

export const cyan_fish_seg6_texture_0600D468 = []
