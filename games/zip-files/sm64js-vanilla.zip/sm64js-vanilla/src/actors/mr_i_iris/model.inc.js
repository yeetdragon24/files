// ** actors/mr_i_iris/model
import * as Gbi from "../../include/gbi"

export const mr_i_iris_seg6_texture_06002170 = []
export const mr_i_iris_seg6_texture_06002970 = []
export const mr_i_iris_seg6_texture_06003170 = []
export const mr_i_iris_seg6_texture_06003970 = []
