// ** actors/tornado/model
import * as Gbi from "../../include/gbi"

export const tornado_seg5_texture_05013128 = []
