// ** actors/piranha_plant/model
import * as Gbi from "../../include/gbi"

export const piranha_plant_seg6_texture_060113F8 = []
export const piranha_plant_seg6_texture_060123F8 = []
export const piranha_plant_seg6_texture_06012BF8 = []
export const piranha_plant_seg6_texture_060133F8 = []
export const piranha_plant_seg6_texture_06013BF8 = []
export const piranha_plant_seg6_texture_060143F8 = []
