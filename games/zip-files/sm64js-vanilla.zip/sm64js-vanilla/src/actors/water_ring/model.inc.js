// ** actors/water_ring/model
import * as Gbi from "../../include/gbi"

export const water_ring_seg6_texture_06012380 = []
