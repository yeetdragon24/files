// ** actors/penguin/model
import * as Gbi from "../../include/gbi"

export const penguin_seg5_texture_05002DE0 = []
export const penguin_seg5_texture_050035E0 = []
export const penguin_seg5_texture_05003DE0 = []
export const penguin_seg5_texture_050045E0 = []
export const penguin_seg5_texture_05004DE0 = []
export const penguin_seg5_texture_050055E0 = []
