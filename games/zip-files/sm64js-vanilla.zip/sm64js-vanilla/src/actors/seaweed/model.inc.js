// ** actors/seaweed/model
import * as Gbi from "../../include/gbi"

export const seaweed_seg6_texture_06007E10 = []
export const seaweed_seg6_texture_06008610 = []
export const seaweed_seg6_texture_06008E10 = []
export const seaweed_seg6_texture_06009610 = []
