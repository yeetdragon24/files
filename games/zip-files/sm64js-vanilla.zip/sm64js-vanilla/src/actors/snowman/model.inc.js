// ** actors/snowman/model
import * as Gbi from "../../include/gbi"

export const snowman_seg5_texture_05008C70 = []
export const snowman_seg5_texture_05009470 = []
export const snowman_seg5_texture_0500A470 = []
export const snowman_seg5_texture_0500B470 = []
export const snowman_seg5_texture_0500BC70 = []
