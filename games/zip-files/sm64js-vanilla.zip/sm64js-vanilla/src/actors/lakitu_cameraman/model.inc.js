// ** actors/lakitu_cameraman/model
import * as Gbi from "../../include/gbi"

export const lakitu_seg6_texture_06000000 = []
export const lakitu_seg6_texture_06000800 = []
export const lakitu_seg6_texture_06001800 = []
export const lakitu_seg6_texture_06002800 = []
export const lakitu_seg6_texture_06003000 = []
export const lakitu_seg6_texture_06003800 = []
