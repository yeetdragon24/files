// ** actors/king_bobomb/model
import * as Gbi from "../../include/gbi"

export const king_bobomb_seg5_texture_05000078 = []
export const king_bobomb_seg5_texture_05001078 = []
export const king_bobomb_seg5_texture_05002078 = []
export const king_bobomb_seg5_texture_05002878 = []
export const king_bobomb_seg5_texture_05004878 = []
export const king_bobomb_seg5_texture_05005878 = []
export const king_bobomb_seg5_texture_05006078 = []
export const king_bobomb_seg5_texture_05006478 = []
export const king_bobomb_seg5_texture_05008478 = []
export const king_bobomb_seg5_texture_05009478 = []
