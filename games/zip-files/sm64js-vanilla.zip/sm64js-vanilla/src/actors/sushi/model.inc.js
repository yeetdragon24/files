// ** actors/sushi/model
import * as Gbi from "../../include/gbi"

export const sushi_seg5_texture_05008ED0 = []
export const sushi_seg5_texture_050096D0 = []
export const sushi_seg5_texture_05009AD0 = []
