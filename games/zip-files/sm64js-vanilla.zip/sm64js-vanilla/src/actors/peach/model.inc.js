// ** actors/peach/model
import * as Gbi from "../../include/gbi"

export const peach_seg5_texture_05000A28 = []
export const peach_seg5_texture_05001228 = []
export const peach_seg5_texture_05001A28 = []
export const peach_seg5_texture_05002228 = []
export const peach_seg5_texture_05002A28 = []
export const peach_seg5_texture_05002C28 = []
export const peach_seg5_texture_05002E28 = []
export const peach_seg5_texture_05003628 = []
export const peach_seg5_texture_05003E28 = []
export const peach_seg5_texture_05004028 = []
