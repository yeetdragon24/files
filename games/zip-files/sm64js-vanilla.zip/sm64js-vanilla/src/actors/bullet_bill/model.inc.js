// ** actors/bullet_bill/model
import * as Gbi from "../../include/gbi"

export const bullet_bill_seg5_texture_0500BAA8 = []
export const bullet_bill_seg5_texture_0500CAA8 = []
