// ** actors/manta/model
import * as Gbi from "../../include/gbi"

export const manta_seg5_texture_050017A0 = []
export const manta_seg5_texture_05001FA0 = []
export const manta_seg5_texture_05002FA0 = []
export const manta_seg5_texture_050037A0 = []
