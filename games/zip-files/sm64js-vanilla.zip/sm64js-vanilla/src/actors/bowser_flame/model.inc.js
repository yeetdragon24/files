// ** actors/bowser_flame/model
import * as Gbi from "../../include/gbi"

export const flame_seg6_texture_06000000 = []
export const flame_seg6_texture_06002000 = []
export const flame_seg6_texture_06004000 = []
export const flame_seg6_texture_06006000 = []
export const flame_seg6_texture_06008000 = []
export const flame_seg6_texture_0600A000 = []
export const flame_seg6_texture_0600C000 = []
export const flame_seg6_texture_0600E000 = []
export const flame_seg6_texture_06010000 = []
export const flame_seg6_texture_06012000 = []
export const flame_seg6_texture_06014000 = []
export const flame_seg6_texture_06016000 = []
export const flame_seg6_texture_06018000 = []
export const flame_seg6_texture_0601A000 = []
