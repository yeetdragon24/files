// ** actors/bub/model
import * as Gbi from "../../include/gbi"

export const bub_seg6_texture_0600E2A8 = []
export const bub_seg6_texture_0600EAA8 = []
export const bub_seg6_texture_0600F2A8 = []
export const bub_seg6_texture_060102A8 = []
