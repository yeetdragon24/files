// ** actors/skeeter/model
import * as Gbi from "../../include/gbi"

export const skeeter_seg6_texture_06000090 = []
export const skeeter_seg6_texture_06000890 = []
