// ** actors/wiggler_body/model
import * as Gbi from "../../include/gbi"

export const wiggler_seg5_texture_05005A30 = []
export const wiggler_seg5_texture_05006A30 = []
export const wiggler_seg5_texture_05007A30 = []
export const wiggler_seg5_texture_05008230 = []
export const wiggler_seg5_texture_05008A30 = []
export const wiggler_seg5_texture_05009230 = []
export const wiggler_seg5_texture_0500A230 = []
