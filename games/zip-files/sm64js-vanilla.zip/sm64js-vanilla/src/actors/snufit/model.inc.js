// ** actors/snufit/model
import * as Gbi from "../../include/gbi"

export const snufit_seg6_texture_060070E0 = []
export const snufit_seg6_texture_060078E0 = []
export const snufit_seg6_texture_060080E0 = []
export const snufit_seg6_texture_060084E0 = []
