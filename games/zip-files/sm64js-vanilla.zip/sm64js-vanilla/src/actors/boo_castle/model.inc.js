// ** actors/boo_castle/model
import * as Gbi from "../../include/gbi"

export const boo_castle_seg6_texture_06015670 = []
export const boo_castle_seg6_texture_06016670 = []
