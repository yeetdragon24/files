# TODO

### Contact me for now - Discord: snuffysasa#2779  

### Prettier formatting settings:
"prettier.semi": false,  
"prettier.tabWidth": 4,  
"prettier.printWidth": 120  