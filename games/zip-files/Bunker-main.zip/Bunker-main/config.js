window._config = {
	"apps": [
		"prxyz",
		"info",
		"mpviewer",
		"conn_stats",
		"sample-games"
	]
}