window.apps["sample-games"] = {};
window.apps["sample-games"]["tile"] = `<div class="box_widget">
	<div>
		<h3>Sample Game Selection</h3>	
	</div>
	<div>
		<ul class="list">
			<li><a href="javascript:goInternal('/apps/sample-games/games.html')">Open full game list</a></li>
			<li>gane*</li>
		</ul>
	</div>
</div>`;