window.apps["mpviewer"] = {};
window.apps["mpviewer"]["tile"] = `<div class="box_widget">
	<div>
		<h3>File Viewer</h3>	
	</div>
	<div>
		<ul class="list">
			<li>Supports most audio and video file formats</li>
			<li><a href="apps/mpviewer/upload.html">Upload to watch/listen</a></li>
		</ul>
	</div>
</div>`;