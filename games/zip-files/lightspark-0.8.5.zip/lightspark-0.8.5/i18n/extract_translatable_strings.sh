#!/bin/sh
xgettext -k_ -d lightspark -s -o lightspark.pot ../*.cpp ../*/*.cpp ../*.h ../*/*.h
